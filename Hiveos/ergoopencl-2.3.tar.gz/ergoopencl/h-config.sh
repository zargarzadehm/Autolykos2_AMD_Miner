#!/usr/bin/env bash
# This code is included in /hive/bin/custom function

[ -t 1 ] && . colors
. $MINER_DIR/$CUSTOM_MINER/h-manifest.conf
#. h-manifest.conf
#. $MINER_DIR/$CUSTOM_MINER/$CUSTOM_NAME.conf
#. $CUSTOM_NAME.conf

[[ -z $CUSTOM_TEMPLATE ]] && echo -e "${YELLOW}CUSTOM_TEMPLATE is empty${NOCOLOR}" && return 1
[[ -z $CUSTOM_URL ]] && echo -e "${YELLOW}CUSTOM_URL is empty${NOCOLOR}" && return 1
#[[ -z $CUSTOM_PASS ]] && CUSTOM_PASS="x"
#[[ -z $SEED ]] && echo -e "${RED}SEED is empty${NOCOLOR}" |tee $CUSTOM_LOG_BASENAME.log && return 1


#CUSTOM_TEMPLATE="${CUSTOM_TEMPLATE//[[:space:]]/}"
#CUSTOM_ADDRESS=`echo $CUSTOM_TEMPLATE | cut -d "." -f1`
#conf="-a=${CUSTOM_ADDRESS} -s=${CUSTOM_URL} -n=${WORKER_NAME} ${CUSTOM_USER_CONFIG}"
conf="{ "
if [[ ! -z $CUSTOM_USER_CONFIG ]]; then
        while read -r line; do
                        [[ -z $line ]] && continue
			conf=$conf$line", "
        done <<< "$CUSTOM_USER_CONFIG"
fi
conf=`echo $conf | rev | cut -d',' -f 2- | rev`
conf=$conf" }"
#echo $conf





[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && return 1
echo $conf > $CUSTOM_CONFIG_FILENAME
